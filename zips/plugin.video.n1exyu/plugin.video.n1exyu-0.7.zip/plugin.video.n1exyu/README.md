Tv N1 for XBMC
========================

### Summary ###
This is a plugin for [XBMC](http://xbmc.org) that enables watching videos and
the live stream from <http://rs.n1info.com>.

### Setup/Installation ###
The plugin should be available in the official XBMC addon repository [not yet].
You can install it within XBMC.

Contact: <zchira@gmail.com>