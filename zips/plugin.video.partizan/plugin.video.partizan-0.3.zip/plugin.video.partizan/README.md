Partizan TV for XBMC
========================

### Summary ###
This is a plugin for [XBMC](http://xbmc.org) that enables watching videos and
the live stream from Partizan Tv.
<https://en.wikipedia.org/wiki/JSD_Partizan>

### Setup/Installation ###
The plugin should be available in the official XBMC addon repository [not yet].
You can install it within XBMC.

Contact: <zchira@gmail.com>